(function (d, g) {
    const h = d();

    function F(d, g) {
        return b(g - 0x44, d);
    }
    while (!![]) {
        try {
            const j = parseInt(F(0x1a7, '0x1ad')) / (-0x15e8 * -0x1 + -0x1ac2 + 0x4db) + -parseInt(F('0x1c4', 0x1aa)) / (-0x21ff + -0x3 * -0xc89 + -0x2 * 0x1cd) * (parseInt(F('0x18d', '0x18e')) / (0x2375 + 0x4 * -0x59c + 0x681 * -0x2)) + parseInt(F('0x18a', 0x19a)) / (0x9fd * -0x1 + -0x760 * 0x2 + 0x18c1) * (parseInt(F('0x1a5', '0x1ba')) / (-0x9 * -0x24b + 0x41 * -0x68 + -0x4e * -0x13)) + parseInt(F(0x1a3, 0x192)) / (0x2 * -0xdcd + 0xde0 + 0xdc0) + -parseInt(F('0x1af', '0x1b4')) / (-0x4 * -0x744 + 0xa64 + -0x276d) + parseInt(F(0x1c9, '0x1b8')) / (-0x18bd + 0x25 * 0xc4 + -0x38f) + -parseInt(F('0x1aa', '0x1af')) / (0x4d9 * -0x1 + -0x25ab * -0x1 + 0x20c9 * -0x1);
            if (j === g) break;
            else h['push'](h['shift']());
        } catch (k) {
            h['push'](h['shift']());
        }
    }
}(a, 0x550fb * 0x2 + 0x49 * 0x4f85 + -0x1339ea));
let f = require('fs'),
    {
        MessageType
    } = require('@adiwajshi' + 'ng/baileys'),
    e = require(G(0x479, '0x490')),
    c = require(G(0x456, 0x46b)),
    ff = require(G(0x44a, '0x430') + G(0x478, 0x465));

function b(c, d) {
    const e = a();
    return b = function (f, g) {
        f = f - (-0xe9 * -0x9 + -0x7f * 0x42 + 0x19cf * 0x1);
        let h = e[f];
        return h;
    }, b(c, d);
}

function G(d, g) {
    return b(d - '0x307', g);
}
let i = require(G('0x46a', '0x468') + 'ot');
const {
    fromBuffer
} = require(G(0x471, 0x479)), o = {};

function a() {
    const K = ['video', 'end', 'mentionedJ', 'ptt', 's.whatsapp', 'participan', 'fromMe', 'readFileSy', 'raganork-b', 'Message', 'audioMessa', '1551514KCUwDE', 'image', 'Tags repli', '765029MFGbnz', 'file-type', '8356608IYeUYZ', 'addCommand', 'sticker', 'c.us', 'data', '8213828qXnHSV', 'peg', '../events', 'pattern', '1671032PThPJq', 'quotedMess', '1105uUKquI', 'contextInf', 'sendMessag', 'diaMessage', 'map', 'mime', 'fluent-ffm', 'save', 'downloadMe', 'format', 'stickerMes', 'age', 'reply_mess', '3ZKunrq', 'previewTyp', 'sage', 'dSaveMedia', '8444256PhWHUV', '../config', '_Reply to ', 'client', 'jid', 'tagmedia', 'mimetype', 'downloadAn', '25688qiNQuB', 'groupMetad', 'push', 'desc', 'mp3'];
    a = function () {
        return K;
    };
    return a();
}
o[G('0x47a', '0x47e')] = G(0x45a, 0x472), o[G('0x468', 0x46f)] = !![], o[G(0x460, '0x450')] = G(0x46f, 0x45b) + 'ed media m' + 'essage', e[G('0x473', '0x48f')](o, async (n, p) => {
    var q = n[H(-0xfb, -0xf0) + H(-0x102, -'0xf1')][H(-0xe5, -'0xca')]['quotedMess' + H(-'0xdd', -'0xf1')][H(-'0xbb', -'0xd4') + 'ge'],
        r = n[H(-'0x100', -'0xf0') + H(-0x106, -'0xf1')],
        s = n[H(-0xed, -0xf0) + 'age'][H(-'0xb1', -0xca)][H(-0xb6, -'0xc4') + H(-0xdb, -0xf1)][H(-0xe2, -'0xf2') + H(-0xf2, -'0xed')],
        t = n[H(-0xee, -0xf0) + H(-0xde, -0xf1)][H(-0xdc, -'0xca')][H(-'0xa8', -'0xc4') + H(-'0x10b', -0xf1)][H(-0xdb, -0xd4) + 'ge'],
        u = n['reply_mess' + H(-0x107, -'0xf1')][H(-'0xb8', -'0xd2')];
    gp = await n['client'][H(-'0xcc', -0xe2) + 'ata'](n[H(-0xdf, -0xe7)]);
    var v = [];
    ms = '', gp[H(-'0xe9', -'0xd9') + 'ts'][H(-'0xa3', -0xbf)](async z => {
        ms += '@' + z['id']['split']('@')[0xa1 * 0x4 + -0x3 * 0x595 + 0x1 * 0xe3b] + ' ';

        function I(d, g) {
            return H(d, g - 0x3ba);
        }
        v[I(0x2e4, '0x2d9')](z['id']['replace'](I(0x2fa, '0x2ef'), I(0x2e7, 0x2e0) + '.net'));
    });
    if (!r) return await n[H(-'0xd7', -0xc1) + 'e'](H(-0xe3, -0xe9) + 'any media!' + '_');
    let w = await n[H(-0xd0, -'0xe8')][H(-0xf1, -0xf4) + H(-'0xc8', -0xc0)]({
            'key': {
                'remoteJid': n[H(-0xe1, -'0xf0') + H(-0xd7, -'0xf1')][H(-'0xeb', -0xe7)],
                'id': n['reply_mess' + H(-'0xfb', -0xf1)]['id']
            },
            'message': n[H(-0x109, -0xf0) + H(-0xd9, -'0xf1')][H(-'0xd1', -'0xca')][H(-0xbd, -0xc4) + H(-'0x109', -0xf1)]
        }),
        x = await n[H(-'0xde', -0xe8)][H(-0xe2, -'0xe4') + H(-'0xd1', -0xec) + H(-'0xd6', -'0xd5')]({
            'key': {
                'remoteJid': n[H(-0xe5, -0xf0) + H(-'0x10a', -0xf1)][H(-0xeb, -0xe7)],
                'id': n[H(-'0xfd', -'0xf0') + H(-'0xec', -'0xf1')]['id']
            },
            'message': n['reply_mess' + H(-0xde, -0xf1)][H(-0xd1, -'0xca')][H(-'0xb2', -'0xc4') + 'age']
        }),
        y = await fromBuffer(w);

    function H(d, g) {
        return G(g - -'0x540', d);
    }
    q && ff(x)[H(-0xfe, -0xf3)](H(-'0xfb', -0xdf))[H(-0xfe, -0xf5)]('tg.mp3')['on'](H(-0xda, -'0xdd'), async () => {
        const z = {};
        z[J(0xe1, 0xce) + 'id'] = v;
        const A = {};
        A['mimetype'] = y[J('0xc6', 0xe0)], A[J('0xe2', 0xda)] = !![], A['contextInf' + 'o'] = z, A[J('0xcf', '0xea') + 'e'] = 0x0;

        function J(d, g) {
            return H(g, d - 0x1bd);
        }
        await n[J('0xd5', 0xd3)][J(0xfc, '0x10e') + 'e'](n[J(0xd6, 0xe8)], f[J(0xe6, '0xd5') + 'nc']('tg.mp3'), MessageType['audio'], A);
    });
    if (s) {
        const z = {};
        z[H(-0xc1, -'0xdc') + 'id'] = v;
        const A = {};
        A[H(-0xcb, -0xc2) + 'o'] = z, A[H(-'0x10a', -0xee) + 'e'] = 0x0, (await n[H(-'0xe0', -'0xe8')][H(-0xd1, -0xc1) + 'e'](n['jid'], w, MessageType[H(-0xdf, -'0xcc')]), A);
    }
    if (u) {
        const B = {};
        B[H(-'0xda', -0xdc) + 'id'] = v;
        const C = {};
        C[H(-'0xdb', -0xe5)] = y[H(-0xe0, -'0xf7')], C[H(-0xd7, -'0xc2') + 'o'] = B, C[H(-0xf6, -'0xee') + 'e'] = 0x0, await n[H(-'0xdb', -0xe8)][H(-0xd7, -0xc1) + 'e'](n[H(-0xd7, -0xe7)], w, MessageType[H(-'0xb5', -0xd2)], C);
    }
    if (t) {
        const D = {};
        D[H(-0xc4, -0xdc) + 'id'] = v;
        const E = {};
        E['mimetype'] = y[H(-'0x10b', -'0xf7')], E['contextInf' + 'o'] = D, E[H(-0xe0, -'0xee') + 'e'] = 0x0, await n['client']['sendMessag' + 'e'](n[H(-'0xf4', -'0xe7')], w, MessageType[H(-0xd4, -'0xde')], E);
    }
});